#!/usr/bin/env python3
"""
Einfacher API-Call an lokales Ollama Modell
Verwendet: qwen2.5-coder:3b
"""
import ollama

def main():
    print(" Ollama Chat gestartet")
    print(" Modell: qwen2.5-coder:3b")
    print("=" * 60)
    
    # Frage eingeben
    frage = input("\nIhre Frage: ").strip()
    
    if not frage:
        print("Keine Frage eingegeben.")
        return
    
    # API-Call an Ollama
    print("\n Sende Anfrage an Ollama...")
    
    try:
        response = ollama.chat(
            model='qwen2.5-coder:3b',
            messages=[
                {
                    'role': 'user',
                    'content': frage
                }
            ]
        )
        
        # Antwort ausgeben
        print("\n Antwort:")
        print(response['message']['content'])
        print()
        
    except Exception as e:
        print(f"\n Fehler bei der Kommunikation mit Ollama: {e}")
        print("\nStellen Sie sicher, dass:")
        print("  1. Ollama läuft (ollama serve)")
        print("  2. Das Modell qwen2.5-coder:3b installiert ist")
        print("     (ollama pull qwen2.5-coder:3b)")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n Programm beendet.")
    except Exception as e:
        print(f"\n Fehler: {e}\n")
